# Homepage
A simple website having similar homepage that of Netflixx using using HTML ,CSS and JAVASCRIPT.
